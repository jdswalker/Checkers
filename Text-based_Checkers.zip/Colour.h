// Authors: @JDSWalker and @ColinVDH
// Copyrighted 2016 under the MIT license:
//  http://www.opensource.org/licenses/mit-license.php

#ifndef CHECKERS_ENUM_FOR_PIECE_COLOURS_H_
#define CHECKERS_ENUM_FOR_PIECE_COLOURS_H_

enum class Colour { DARK, LIGHT };

#endif // CHECKERS_ENUM_FOR_PIECE_COLOURS_H_
